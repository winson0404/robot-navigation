startMarker = 60 # "<"
endMarker = 62  # ">"
arduino_start_message = b"started"
system_endian = "little" # little/big